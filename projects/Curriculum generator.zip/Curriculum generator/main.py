# main.py

import tkinter as tk
from interface import GeradorCurriculoApp

if __name__ == "__main__":
    root = tk.Tk()
    app = GeradorCurriculoApp(root)
    root.mainloop()
